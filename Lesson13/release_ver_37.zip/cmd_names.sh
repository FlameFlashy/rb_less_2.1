#!/bin/bash/
col_str=$(wc -l usr_executables.txt)
echo "$col_str"
link=$(head -10 usr_executables.txt)
